package pe.edu.upeu.app;

import pe.edu.upeu.gui.MainGUI;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
        //System.out.println("Hello World!");
        //new MainGUI();
        new MenuOpciones().login();
    }
}
